Database configuration in:
inc/db.inc.php file

You will need to correct:
$this->sDbName = 'database_name';
$this->sDbUser = 'database_username';
$this->sDbPass = 'database_password';
